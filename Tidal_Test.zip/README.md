# TIDAL Plugin for Squeezebox

## TODO

* a lot
* use [latest API](https://developer.tidal.com/documentation/api/api-reference) once it's stable and released

## Thanks!

This implementation was inspired by the following projects:

* https://github.com/tamland/python-tidal
* https://github.com/Fokka-Engineering/libopenTIDAL
* https://tidalapi.netlify.app